# BridgeTut demo snapshot

Supports macOS and Linux with a graphical desktop. Requires Java 17 or later,
Python 3, a C++11 compiler (`c++`, or set CXX), and `ar`.
Maven and internet access are not required to run this package.

Extract the complete package to a writable folder, then run:

```sh
sh run-demo.sh
```

This builds bundled DDS for your computer and runs the already compiled JAR.
The launcher locates its own folder, so it also works from another directory.
Keep `native/` and `tutorials/` alongside the JAR. The JAR alone is not a complete
DDS-enabled distribution. Windows is not supported by this launcher.
Profiles and saved games are stored in `~/.bridgetut`.

## Add to the repository

Copy `BridgeTut.jar` to the repository root, replacing the old JAR.
Copy `run-demo.sh`, `SNAPSHOT.txt` and this README to the root too.
The bundled native and tutorial files match the source commit in SNAPSHOT.txt;
keep those versions with this demo. The existing development launcher may remain.
Commit these files and link the report to that commit's JAR or, preferably,
the complete ZIP snapshot. Do not use a moving main-branch link.

The JAR contains SQLite JDBC and its bundled native libraries; their license
notices are retained in META-INF. DDS licensing is in native/vendor/dds-2.9.0/LICENSE.
